# BridgeSession1GUI

The Start.jar file is the executable JAR file. It can be run from terminal. In order to do that, follow these steps:

 - Open your Command Prompt / OSX Terminal
 - Navigate to where you have the Start.jar file
 - Type "java -jar Start.jar"
 
If you get the error "XXXXX cannot be resolved to a type", import the  libraries 

 - pdfbox-app-1.8.10.jar
 - ziputils-1.2.jar
 
For any questions about the code implementation or so, please feel free to reach us at 

  Victoria Shurman : vshurman@cs.purdue.edu
  Sahil Pujari : pujari@cs.purdue.edu
